# Vibe Code Way skills (6 ตัว) — Gen AI Space

ทุกโฟลเดอร์ในนี้คือ 1 skill (มี SKILL.md ข้างใน) ใช้ได้ทั้ง Claude Code และ Codex

| skill | ใช้ในขั้น | ทำอะไร |
|---|---|---|
| grill-with-doc | 3 grill | จี้ถามทีละข้อจนโจทย์ชัด แล้วบันทึกเป็นเอกสาร |
| wayfinder-for-web-app-game | 4 way finder | สรุปทางเลือก 3 ข้อ + เคาะข้อที่ควรเลือก เมื่อลังเล |
| agent-to-subagent | 5 subagent | ตัวหลักวางแผน แบ่งงานให้ทีม subagent 3–5 ตัว ขออนุมัติก่อนแจกงาน แล้วตรวจรวม |
| to-prd | 7 PRD | เขียนสเปกงาน (PRD) จากที่คุยกันและ DESIGN.md |
| self-review-to-10 | 8 review 10 | ให้คะแนน PRD/งานเต็ม 10 ระบุจุดหัก แก้จนผ่าน |
| frontend-design | 9 create | ออกแบบหน้าเว็บให้สวยและใช้ได้จริงตอนลงมือสร้าง |

ขั้น 6 design (ออกแบบ UX/UI ทำ DESIGN.md) ไม่ต้องใช้ skill

## ติดตั้ง (ครั้งเดียว)
1. แตก zip นี้ จะได้โฟลเดอร์ 6 โฟลเดอร์ (+ README.md นี้)
2. ลากทั้ง 6 โฟลเดอร์ไปวางในโฟลเดอร์ `my-vibecode-workspace\skills\` (Prompt สร้าง workspace ทำไว้ให้แล้ว ใช้ได้ทั้ง Claude Code และ Codex)
   - อยากใช้กับทุกโปรเจกต์ ให้วางที่นี่แทน (ถ้าไม่มีโฟลเดอร์ ให้สร้างชื่อนี้)
   - Claude Code: `C:\Users\<ชื่อผู้ใช้>\.claude\skills\`
   - Codex: `C:\Users\<ชื่อผู้ใช้>\.codex\skills\`
3. เปิดแอป แล้วสั่งครั้งแรกว่า: "เข้าดูโฟลเดอร์ skills ของคุณ อ่าน README.md และ SKILL.md ของทุก skill แล้วสรุปว่ามีอะไรบ้าง ใช้ตอนไหน"

## วิธีเรียกใช้
พิมพ์ชื่อ skill ในประโยคทุกครั้ง เช่น "ใช้ skill grill-with-doc: ก่อนสร้าง ช่วย grill ผมก่อน ..." ถ้าไม่บอกชื่อ AI จะไม่เรียก skill ให้
