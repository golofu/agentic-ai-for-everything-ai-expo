# Codex runtime

Use this file only when the current runtime exposes `collaboration.spawn_agent`. These are native collaboration calls, not shell commands or public API model names.

| Role | Rule | Typical pairing |
|---|---|---|
| Director | Whatever model the main room is running. Do not ask the user to switch. | `gpt-6-astra` |
| Workers and reviewer | A lighter model than Director, taken from the models the schema lists | `gpt-5.6-luna` |

If Director is already the lightest model available, workers use the same model and the plan says the model split saves nothing this round. Never give a worker a heavier model than Director.

## Check the real capability first

Re-check the available models, efforts, `fork_turns` conditions and concurrent slots before planning. Request the highest effort the worker model supports. Capability observed when this skill was created (2026-09-06): Astra supports `ultra`; Luna tops out at `max`. So a Luna worker runs at `max`, and the plan states that `max` replaces `ultra`. Setting `ultra` on Luna does not make the tool support it.

## Conditional native call example

Only when the current schema supports these exact values and they appear in the approved plan:

```json
{
  "task_name": "source_analyst",
  "fork_turns": "none",
  "model": "gpt-5.6-luna",
  "reasoning_effort": "max",
  "message": "Replace this message with the complete bounded worker brief from dispatch-and-review.md."
}
```

Send this structured argument to `collaboration.spawn_agent`; do not route collaboration tools through `functions.exec`. Use `fork_turns: "none"` so the worker does not copy the whole conversation and so model/effort can be set separately where the runtime enforces that. If overrides require a fresh context, do not use `fork_turns: "all"`. The example does not guarantee the provider executed the requested model when the runtime supplies no confirmation.

## Slots and reuse

If 4 agents may run including root, at most 3 workers run at once. A team of 4–5 roles must run in rounds within the real limit. If completed agents cannot be closed and still consume slots, reuse an existing worker with `collaboration.followup_task`, a fresh bounded brief and new ownership, and disclose the reuse.
