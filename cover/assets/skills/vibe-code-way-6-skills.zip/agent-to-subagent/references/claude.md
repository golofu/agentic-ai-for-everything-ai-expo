# Claude Code runtime

Use this file only when the current runtime exposes the `Agent` tool with a `model` parameter. The rule: **the model the main session is running is Director; workers run one step smaller.**

| Director (main session) | Workers and reviewer (`Agent` `model`) |
|---|---|
| Fable | `"sonnet"` |
| Opus | `"sonnet"` |
| Sonnet | `"haiku"` |
| Haiku | `"haiku"` (same model; the plan says the split saves nothing this round) |

Do not ask the user to switch models before starting. Never give a worker a heavier model than Director.

## Check the real capability first

- **Director model.** Read the model name the session reports about itself and state it in the plan. If the session does not report it, say it could not be confirmed. Do not spawn a subagent to act as Director.
- **Worker model.** Confirm the `Agent` schema lists the worker value in its `model` options. If it does not, use the nearest smaller value it does list and state that in the plan.
- **Effort.** The `Agent` call has no per-call effort parameter; a subagent's effort comes from its agent definition. Report worker effort as "runtime default, not set by this skill". Never claim a specific effort you could not set.
- **Model confirmation.** The runtime may not return proof of which model ran. Report the value as requested unless the result confirms it.
- **No `Agent` tool** (for example claude.ai chat): propose the plan only and state the limit. Do not role-play several agents in one room.

## Spawning a worker

```json
{
  "description": "Source analyst",
  "subagent_type": "general-purpose",
  "model": "sonnet",
  "prompt": "Replace this with the complete bounded worker brief from dispatch-and-review.md."
}
```

- Use a fresh agent (`general-purpose`, or omit `subagent_type`) so the worker starts cold with only the brief. This is the equivalent of Codex `fork_turns: "none"`.
- **Never use `subagent_type: "fork"` for a worker.** A fork inherits the whole conversation and always runs on Director's own model; the `model` override is ignored, so the work would not move to the smaller model.
- The worker cannot see this conversation. Put absolute paths, the acceptance criteria and any workspace rules it needs directly in the brief.
- An `Agent` override for `model` takes precedence over the agent definition's own model, so a project-defined agent type can still be pinned to the worker model when its role fits.

## Parallel rounds and reuse

- Put independent `Agent` calls in **one message** so they run in parallel. Start dependent roles only after their inputs are stable.
- Workers run in the background and report back when done. Do not predict or fabricate a result that has not arrived.
- To give a finished worker the next role or a fix round, continue it with `SendMessage` to its ID, with a fresh bounded brief and new ownership, and disclose the reuse. A new `Agent` call starts fresh instead.
- Keep at least one reviewer that did not author the artifact under review. If that is impossible, disclose it and have Director do the independent check.
