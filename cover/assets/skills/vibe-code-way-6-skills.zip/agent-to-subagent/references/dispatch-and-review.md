# Dispatch and review contract

Use only after the user approves the concrete plan. Re-check the current tool schema. For the actual tool call, read the file for the platform you are running on: [codex.md](codex.md) or [claude.md](claude.md).

## Minimal worker brief

```text
Role: [task-specific role]
Objective: [one bounded result]
Approved scope and model deviation: [exact approved plan]
Inputs: [absolute paths or the necessary excerpts; source authority]
Relevant instructions: [applicable workspace constraints and skill paths]
Dependencies: [ready artifact/version or wait condition]
Ownership: [files you may edit; everything else read-only]
Acceptance: [observable criteria]
Verification: [commands from project files or document/source checks]
Deliver: [artifact paths + short report using the format below]
Limits: Do not spawn agents, modify unrelated files, revert others' changes,
change provider/model/scope, or take unauthorized external actions.
If blocked: return the precise missing input or failed check to Director.
```

Worker report: status (`done`, `partial`, `blocked`), artifact paths, decisions/assumptions that affect integration, verification commands and actual outcomes, unresolved findings with evidence. Keep ordinary reports under approximately 250–400 words; short tasks may need only a few lines. This is a ceiling, not a target. Include essential failure evidence even if it needs more space. Keep long details in an artifact accessible to Director.

## Roles versus simultaneous workers

A role is not necessarily a simultaneous process. For a five-role plan with three worker slots, run the independent ready tasks first. Start downstream roles only after their inputs stabilize. If a finished worker must take the next role, reuse it with a fresh bounded brief and new ownership, and disclose the reuse. Reserve a worker who did not author the reviewed artifact for the independent review. If this is impossible, disclose the reduced independence and have Director perform the independent check.

## Director acceptance record

For each agreed criterion record the actual evidence and pass/fail/not-tested result. Check the final artifact, not only individual pieces. A green worker report cannot override a failed command, missing source, broken link, inconsistent calculation or uninspected export.

Use relevant checks: coding = changed behavior plus meaningful regression and project checks; research = source coverage and supported claims; data = reconciliation and calculation; workshop = audience fit, workable exercises, time sum and measurable outcomes; documents/media = content plus rendered output.

Keep the result in the task's existing working area when useful. This record does not authorize writing to wiki, memory, or publishing a report.
