---
name: to-prd
description: Turn the current conversation into a PRD and publish it to the project issue tracker — no interview, just synthesis of what you've already discussed.
---

This skill synthesizes the current conversation and codebase understanding into a PRD. Do not repeat an interview when the discussion already supplies the problem, intended outcome and scope. If those essentials are absent, ask one focused question for the missing brief and stop short of inventing decisions; unresolved details remain explicit open questions in a draft.

Resolve the issue tracker, destination project and triage vocabulary from repository instructions/configuration and the current conversation. Do not invoke an absent setup command. If the destination cannot be resolved, prepare the PRD draft locally and ask for the missing destination before publishing.

## Process

1. Explore the repo to understand the current state of the codebase, if you haven't already. Use the project's domain glossary vocabulary throughout the PRD, and respect any ADRs in the area you're touching.

2. Sketch out the seams at which you're going to test the feature. Existing seams should be preferred to new ones. Use the highest seam possible. If new seams are needed, propose them at the highest point you can. The fewer seams across the codebase, the better - the ideal number is one.

Check with the user that these seams match their expectations.

3. Write the PRD using the template below. Compare each requirement and decision with the conversation and repo evidence; acceptance conditions must be observable and critical open questions resolved before applying a ready label. When publication is authorized and the destination is known, publish and read back the issue title/body, destination and labels. Apply `ready-for-agent` only if that label exists in the project's vocabulary and readiness is established. Otherwise retain a draft/open-question status and report the missing decisions; do not present successful creation alone as readiness.

<prd-template>

## Problem Statement

The problem that the user is facing, from the user's perspective.

## Solution

The solution to the problem, from the user's perspective.

## User Stories

A LONG, numbered list of user stories. Each user story should be in the format of:

1. As an <actor>, I want a <feature>, so that <benefit>

<user-story-example>
1. As a mobile bank customer, I want to see balance on my accounts, so that I can make better informed decisions about my spending
</user-story-example>

This list of user stories should be extremely extensive and cover all aspects of the feature.

## Implementation Decisions

A list of implementation decisions that were made. This can include:

- The modules that will be built/modified
- The interfaces of those modules that will be modified
- Technical clarifications from the developer
- Architectural decisions
- Schema changes
- API contracts
- Specific interactions

Do NOT include specific file paths or code snippets. They may end up being outdated very quickly.

Exception: if a prototype produced a snippet that encodes a decision more precisely than prose can (state machine, reducer, schema, type shape), inline it within the relevant decision and note briefly that it came from a prototype. Trim to the decision-rich parts — not a working demo, just the important bits.

## Testing Decisions

A list of testing decisions that were made. Include:

- A description of what makes a good test (only test external behavior, not implementation details)
- Which modules will be tested
- Prior art for the tests (i.e. similar types of tests in the codebase)

## Out of Scope

A description of the things that are out of scope for this PRD.

## Further Notes

Any further notes about the feature.

</prd-template>
