# ผลลัพธ์ที่ควรได้ — ทำชุด Brief แคมเปญ

- output/campaign-brief.docx
- output/posts.md
- output/image-briefs.md
- output/landing-outline.md

## จุดตรวจ
ชุดงานใช้ข้อเสนอราคาปลีก 480 บาท และมี Brief พร้อมส่งต่อทำภาพและเว็บ

เอกสารนี้เป็นแนวทางตรวจผลที่คาดหวังจากข้อมูลตัวอย่าง ไม่ใช่รายงานว่า Agent ได้ทำงานแล้ว
