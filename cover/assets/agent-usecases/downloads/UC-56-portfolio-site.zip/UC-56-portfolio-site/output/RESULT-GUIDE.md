# ผลลัพธ์ที่ควรได้ — ทำเว็บ Portfolio

- output/portfolio/index.html
- output/portfolio/assets/
- output/run-guide.md

## จุดตรวจ
กรองหมวดอีเวนต์แล้วเห็น Desk Day และภาพของงานถูกต้อง

เอกสารนี้เป็นแนวทางตรวจผลที่คาดหวังจากข้อมูลตัวอย่าง ไม่ใช่รายงานว่า Agent ได้ทำงานแล้ว
