# ผลลัพธ์ที่ควรได้ — แปลเอกสารให้ใช้ศัพท์ตรงกัน

- output/order-process-en.docx
- output/service-policy-en.docx
- output/glossary-added.csv

## จุดตรวจ
ใช้ inventory / picking list / tracking number ตรงกัน และจำนวนวันในฉบับแปลตรงต้นฉบับ

เอกสารนี้เป็นแนวทางตรวจผลที่คาดหวังจากข้อมูลตัวอย่าง ไม่ใช่รายงานว่า Agent ได้ทำงานแล้ว
